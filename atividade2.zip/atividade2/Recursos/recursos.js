// importar a biblioteca q use o protocolo http

const http = require('http')
const url = require('url')
const fs = require('fs')

function readFile(response, file){
    fs.readFile(file,function(err, data){
        response.end(data)
    })
}

// criar a função que vai trabalhar no servidor

var callback = function(request, response) {

    var parts = url.parse(request.url)
    var path = parts.path
    
    if (parts.path == "/abertura"){
        response.writeHead(200, {"Content-type" : "text/html"})
        readFile(response, "SiteUnicsul.html")
   
    }else if (parts.path == '/abertura/rota1' ){
        response.writeHead(200, {"Content-type" : "application/vnd.openxmlformats-officedocument.wordprocessingml.document"})
        readFile(response, "lorem.docx")

    }else if (parts.path == '/abertura/rota2' ){
        response.writeHead(200, {"Content-type" : "application/json"})
        readFile(response, "cadastro.json")

    
    }else if (parts.path == '/abertura/rota3' ){
        response.writeHead(200, {"Content-type" : "image/jpeg"})
        readFile(response, "fusca.jpeg")

    
    }else if (parts.path == '/abertura/rota4' ){
        response.writeHead(200, {"Content-type" : "audio/mp3"})
        readFile(response, "topgear.mp3")

    
    }else if (parts.path == '/abertura/rota5' ){
        response.writeHead(200, {"Content-type" : "video/mp4"})
        readFile(response, "video.mp4")


    }else if (parts.path == '/abertura/rota6' ){
        response.writeHead(200, {"Content-type" : "text/html"})
        readFile(response, "SiteUnicsul.html")


    }else {
        response.writeHead(200, {"Content-type" : "text/html"})
        readFile(response, "Site404.html")
    
    }
    
}

// criar o servidor

var server = http.createServer(callback) 
server.listen(3000)
console.log("[SERVER - OK] ...  Servidor montado em http://localhost:3000")