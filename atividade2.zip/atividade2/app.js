import express from 'express'


const app = express()


app.get('/', (req,res) =>{
    res.status(200).send('olá mundo!')
})

app.get('/catalogo',(req,res) =>{
    res.status(200).send(Views)
})

app.get('/contatos',(req,res) =>{
    res.status(200).send('Listas de contatos')
})

app.get('/produtos',(req,res) =>{
    res.status(200).send('Listas de produtos')
})





export default app